Jamaica ug Junnel - Android project

1. Install Android Studio (https://developer.android.com/studio) and unzip this folder.
2. In Android Studio: File > Open, choose this folder, and wait for Gradle sync
   (needs internet the first time; accept any prompt to install SDK 34).
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Click "locate" in the popup. The file is app/build/outputs/apk/debug/app-debug.apk
5. Send the APK to your phone and open it. Allow "install unknown apps" if asked.

The app lives in app/src/main/assets/index.html
